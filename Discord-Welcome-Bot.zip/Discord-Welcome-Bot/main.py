import os
import json
import random
import asyncio
import discord
from discord.ext import commands, tasks
from discord import app_commands
import gspread
from oauth2client.service_account import ServiceAccountCredentials
from flask import Flask
from threading import Thread
from openai import OpenAI

# --- OpenRouter OpenAI Client Setup ---
client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=os.getenv("OPENROUTER_API_KEY"),
)

# --- Keep Alive Webserver ---
app = Flask('')

@app.route('/')
def home():
    return "Fortuna is alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

keep_alive()

# --- Discord Setup ---
TOKEN = os.getenv("DISCORD_TOKEN")
intents = discord.Intents.default()
intents.members = True
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree

# --- Google Sheets Setup ---
scope = ['https://spreadsheets.google.com/feeds',
         'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
gsheet = gspread.authorize(creds)
settings_sheet = gsheet.open("Discord Bot Fics").worksheet("Server Settings")

# --- Load Personality ---
with open("fortuna_personality.json", "r") as f:
    personality_data = json.load(f)

# --- Load persistent data from Google Sheets ---
def load_server_data(guild_id):
    try:
        row = settings_sheet.find(str(guild_id))
        config = settings_sheet.row_values(row.row)
        msg_count = int(config[5]) if len(config) > 5 else 0
        stage = config[6] if len(config) > 6 else personality_data['stages'][0]['name']
        return msg_count, stage
    except:
        return 0, personality_data['stages'][0]['name']

# Temporary default values for current_stage and message_count
current_stage = personality_data['stages'][0]['name']
message_count = 0

message_thresholds = [s['trigger_message_count'] for s in personality_data['stages'] if s['trigger_message_count'] is not None]

# --- Auto Message Config ---
@tasks.loop(minutes=random.randint(30, 90))
async def send_autonomous_message():
    await bot.wait_until_ready()
    for guild in bot.guilds:
        try:
            row = settings_sheet.find(str(guild.id))
            config = settings_sheet.row_values(row.row)
            channel_id = int(config[1])
            allowed_channels = json.loads(config[4]) if len(config) > 4 else []
            if str(channel_id) not in allowed_channels:
                continue
            channel = guild.get_channel(channel_id)
            if channel:
                _, stage_name = load_server_data(guild.id)
                stage = next((s for s in personality_data['stages'] if s['name'] == stage_name), None)
                if stage:
                    message = random.choice(stage['auto_messages'])
                    await channel.send(message)
        except Exception as e:
            print(f"[AutoMsg ERROR] {e}")

# --- Personality Evolution ---
def evolve_personality(guild_id):
    global current_stage
    for stage in personality_data['stages']:
        if stage['trigger_message_count'] and message_count >= stage['trigger_message_count']:
            current_stage = stage['name']
    try:
        row = settings_sheet.find(str(guild_id))
        settings_sheet.update_cell(row.row, 6, str(message_count))
        settings_sheet.update_cell(row.row, 7, current_stage)
    except Exception as e:
        print(f"[Stage Update ERROR] {e}")

# --- Generate AI Response ---
async def generate_openai_response(prompt):
    try:
        response = client.chat.completions.create(
            model="meta-llama/llama-3.2-1b-instruct:free",
            messages=[
                {"role": "system", "content": "You are Fortuna Astra Duck, an energetic Discord bot with a quirky, sweet personality. You like mild chaos, reading fanfics about Neuroverse Vtubers, and you call gambling 'gamba'."},
                {"role": "user", "content": prompt}
            ]
        )
        return response.choices[0].message.content.strip()
    except Exception as e:
        print(f"[OpenAI ERROR] {e}")
        return None

# --- On Ready ---
@bot.event
async def on_ready():
    print(f"Logged in as {bot.user.name} (ID: {bot.user.id})")
    try:
        for guild in bot.guilds:
            global message_count, current_stage
            message_count, current_stage = load_server_data(guild.id)
            await bot.tree.sync(guild=discord.Object(id=guild.id))
            print(f"✅ Synced commands for {guild.name}")
    except Exception as e:
        print(f"❌ Failed to sync commands: {e}")
    send_autonomous_message.start()

# --- On Member Join ---
@bot.event
async def on_member_join(member):
    try:
        row = settings_sheet.find(str(member.guild.id))
        config = settings_sheet.row_values(row.row)
        channel_id = int(config[1])
        channel = member.guild.get_channel(channel_id)
        sticker_ids = json.loads(config[3]) if len(config) > 3 else []
        if channel:
            content = f"🎉 Welcome to the server, {member.mention}!"
            stickers = []
            if sticker_ids:
                try:
                    s_id = random.choice(sticker_ids)
                    stickers = [await bot.fetch_sticker(s_id)]
                except:
                    pass
            await channel.send(content=content, stickers=stickers)
    except Exception as e:
        print(f"[Welcome ERROR] {e}")

# --- On Message ---
@bot.event
async def on_message(message):
    global message_count
    if message.author == bot.user:
        return

    try:
        row = settings_sheet.find(str(message.guild.id))
        config = settings_sheet.row_values(row.row)
        allowed_channels = json.loads(config[4]) if len(config) > 4 else []
        welcome_channel_id = int(config[1]) if len(config) > 1 else None
        if str(message.channel.id) == str(welcome_channel_id):
            return
        if allowed_channels and str(message.channel.id) not in allowed_channels:
            return
    except Exception as e:
        print(f"[Channel Check ERROR] {e}")
        return

    message_count += 1
    evolve_personality(message.guild.id)

    if not message.content.startswith("/") and not message.content.startswith("!"):
        stage = next((s for s in personality_data['stages'] if s['name'] == current_stage), None)
        if stage:
            chance = stage.get('response_chance', 0.01)  # 1% chance globally
            respond = random.random() < chance or bot.user in message.mentions
            if respond:
                reply = await generate_openai_response(message.content)
                if not reply and stage.get('responses'):
                    reply = random.choice(stage['responses'])
                if reply:
                    try:
                        await message.channel.send(reply)
                        # --- Emoji Reaction ---
                        react_chance = 0.1  # 10% chance to react
                        if random.random() < react_chance or bot.user in message.mentions:
                            emojis = ["💛", "🎲", "📖", "🐤", "✨", "🧠"]
                            emoji = random.choice(emojis)
                            await message.add_reaction(emoji)
                    except Exception as e:
                        print(f"[Response ERROR] {e}")

    await bot.process_commands(message)

# --- Ping Command ---
@tree.command(name="ping", description="Check if Fortuna is alive.")
@app_commands.guilds()
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message("🏓 Pong! Fortuna is online!", ephemeral=True)

# --- Set Allowed Channels Command ---
@tree.command(name="setallowed", description="Set allowed text channels for Fortuna.")
@app_commands.describe(channels="List of channels where Fortuna can respond")
async def setallowed(interaction: discord.Interaction, channels: str):
    try:
        row = settings_sheet.find(str(interaction.guild_id))
        settings_sheet.update_cell(row.row, 5, json.dumps([c.strip() for c in channels.split()]))
        await interaction.response.send_message("✅ Allowed channels updated!", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to update allowed channels: {e}", ephemeral=True)

# --- View Allowed Channels Command ---
@tree.command(name="viewallowed", description="See allowed text channels for Fortuna.")
async def viewallowed(interaction: discord.Interaction):
    try:
        row = settings_sheet.find(str(interaction.guild_id))
        config = settings_sheet.row_values(row.row)
        allowed_channels = json.loads(config[4]) if len(config) > 4 else []
        if allowed_channels:
            mention_list = [f"<#{ch}>" for ch in allowed_channels]
            await interaction.response.send_message(f"📋 Allowed channels: {', '.join(mention_list)}", ephemeral=True)
        else:
            await interaction.response.send_message("⚠️ No allowed channels are set yet.", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to retrieve allowed channels: {e}", ephemeral=True)

# --- Change Stage Command ---
@tree.command(name="setstage", description="Manually set Fortuna's personality stage.")
@app_commands.describe(stage="The name of the stage to set Fortuna to")
async def setstage(interaction: discord.Interaction, stage: str):
    global current_stage
    valid_stages = [s['name'] for s in personality_data['stages']]
    if stage not in valid_stages:
        await interaction.response.send_message(f"❌ Invalid stage name. Valid stages: {', '.join(valid_stages)}", ephemeral=True)
        return
    current_stage = stage
    try:
        row = settings_sheet.find(str(interaction.guild_id))
        settings_sheet.update_cell(row.row, 7, current_stage)
        await interaction.response.send_message(f"✅ Fortuna's stage set to **{stage}**.", ephemeral=True)
    except Exception as e:
        await interaction.response.send_message(f"❌ Failed to update stage: {e}", ephemeral=True)

# --- Run Bot ---
bot.run(TOKEN)
