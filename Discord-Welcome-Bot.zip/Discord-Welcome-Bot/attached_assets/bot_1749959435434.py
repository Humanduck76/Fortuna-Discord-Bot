import os
import random
import discord
from discord import app_commands
from discord.ext import commands
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import asyncio

# For keep_alive webserver
from flask import Flask
from threading import Thread

# --- Keep Alive Server Setup ---

app = Flask('')

@app.route('/')
def home():
    return "I'm alive!"

def run():
    app.run(host='0.0.0.0', port=8080)

def keep_alive():
    t = Thread(target=run)
    t.start()

# Start the keep_alive server
keep_alive()

# --- Bot Setup ---

TOKEN = os.getenv('DISCORD_TOKEN')

# Server IDs
MAIN_SERVER_ID = 1371931390089629756
TEST_SERVER_ID = 1350146255174500464

intents = discord.Intents.default()
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)
tree = bot.tree

# Google Sheets setup
scope = ['https://spreadsheets.google.com/feeds',
         'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('credentials.json', scope)
client = gspread.authorize(creds)
sheet = client.open('Discord Bot Fics').sheet1

# Predefined sticker IDs (ensure these are valid and your bot has access)
STICKER_IDS = [
    1380386277874208800,
    # Add more sticker IDs here if desired
]

def load_fic_authors():
    records = sheet.get_all_records()
    mapping = {}
    for row in records:
        title = row.get('fic_title', '').lower()
        author_id = row.get('author_id')
        if title and author_id:
            try:
                mapping[title] = int(author_id)
            except:
                pass
    return mapping

def add_or_update_fic(title, author_id):
    records = sheet.get_all_records()
    for i, row in enumerate(records, start=2):
        if row.get('fic_title', '').lower() == title.lower():
            sheet.update_cell(i, 2, str(author_id))
            return
    sheet.append_row([title, str(author_id)])

@bot.event
async def on_ready():
    print(f'Logged in as {bot.user} (ID: {bot.user.id})')
    # Sync commands only for the test server to avoid cluttering main
    guild = discord.Object(id=TEST_SERVER_ID)
    try:
        await bot.tree.sync(guild=guild)
        print(f"✅ Slash commands synced for test server {TEST_SERVER_ID}")
    except discord.Forbidden:
        print(f"❌ Missing access to sync commands in test server {TEST_SERVER_ID}")
    except Exception as e:
        print(f"❌ Failed to sync commands in test server {TEST_SERVER_ID}: {e}")

@bot.event
async def on_member_join(member):
    welcome_channels = {
        MAIN_SERVER_ID: 'front-door',          # Your main server welcome channel
        TEST_SERVER_ID: 'welcome-and-rules',   # Your test server welcome channel
    }

    channel_name = welcome_channels.get(member.guild.id)
    if not channel_name:
        print(f"[INFO] No welcome channel configured for guild: {member.guild.name}")
        return

    welcome_channel = discord.utils.get(member.guild.text_channels, name=channel_name)
    if not welcome_channel:
        print(f"[ERROR] Channel '{channel_name}' not found in {member.guild.name}")
        return

    try:
        sticker_id = random.choice(STICKER_IDS)
        sticker = await bot.fetch_sticker(sticker_id)

        await welcome_channel.send(
            content=f"🎉 Welcome to the server, {member.mention}!",
            stickers=[sticker]
        )
    except discord.Forbidden:
        print(f"[ERROR] Missing permission to send messages or stickers in #{channel_name} ({member.guild.name})")
    except Exception as e:
        print(f"[ERROR] Error sending welcome message: {e}")

# Slash command to add fic, ONLY registered in test server
@tree.command(name="addfic", description="Link a fic title to an author.")
@app_commands.describe(title="The fic title", author="The Discord user who wrote it")
@app_commands.guilds(discord.Object(id=TEST_SERVER_ID))
async def addfic(interaction: discord.Interaction, title: str, author: discord.User):
    add_or_update_fic(title, author.id)
    await interaction.response.send_message(f"✅ Fic \"{title}\" has been linked to {author.mention}.", ephemeral=True)

# Run the bot
bot.run(TOKEN)
